"""
bootstrap_nb6.py
────────────────────────────────────────────────────────────────────────────────
Bootstrap evaluation for the regression pipeline (NB6).

Loops over the B bootstrapped Master files from bootstrap_nb3.py, fits
Models 3a and 3b on each, and reports bootstrap confidence intervals for
every coefficient. Also computes the bootstrap standard error (SD of
the B point estimates) alongside the original Driscoll-Kraay SE for
comparison.

USAGE
-----
Paste into a new cell at the end of NB6, after the original pipeline
has run (so that constants like reg3_input, INTERACT_VARS, INCLUDE, and
the original model results m3a/m3b exist in memory).

OUTPUT
------
    intermediary/bootstrap/nb6_boot_coefs_3a.csv
    intermediary/bootstrap/nb6_boot_coefs_3b.csv
    intermediary/bootstrap/nb6_boot_summary.csv
    Console: coefficient CIs and comparison with original estimates
"""

import os
import time
import glob
import warnings
import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

# ── Configuration ─────────────────────────────────────────────────────────────
BOOT_DIR = "intermediary/bootstrap"
ALPHA = 0.05  # for 95% CIs

INCLUDE = [
    'AGO', 'ARE', 'AZE', 'BFA', 'BHR', 'BOL', 'CHL', 'CIV', 'CMR',
    'COD', 'COG', 'DZA', 'ECU', 'EGY', 'ETH', 'GAB', 'GHA', 'GIN',
    'GNQ', 'IDN', 'IRN', 'IRQ', 'KAZ', 'KEN', 'KWT', 'LAO', 'LBR',
    'LBY', 'MDG', 'MLI', 'MMR', 'MNG', 'MOZ', 'MWI', 'MYS', 'NER',
    'NGA', 'OMN', 'PNG', 'QAT', 'RUS', 'RWA', 'SAU', 'TCD', 'TGO',
    'TTO', 'TZA', 'UGA', 'UZB', 'VEN', 'VNM', 'YEM', 'ZMB', 'ZWE',
]

# Regression variable lists (must match NB6 exactly)
reg3_input = [
    'log_HCI', 'log_GFCF', 'Political stability — estimate',
    'Rule of law index', 'log_Production_Value', 'Trade (% of GDP)',
]
INTERACT_VARS = ['log_HCI_x_log_Production', 'log_GFCF_x_log_Production']


def prepare_regression_df(filepath: str) -> pd.DataFrame:
    """
    Load a bootstrapped Master file and apply the same feature engineering
    as NB6: per-capita production value, log transforms, mean-centred
    interactions, and lagged ECI.

    Returns the ready-to-regress DataFrame, or None if too small.
    """
    master = pd.read_csv(filepath)
    df = master[master["Country Code"].isin(INCLUDE)].copy()

    if len(df) < 50:
        return None

    # Per-capita production value
    df["Total_Production_Value_Per_Capita"] = (
        df["Total_Production_Value"] / df["Population"]
    )

    # Log transforms
    df["log_HCI"] = np.log1p(df["Human capital index"])
    df["log_GFCF"] = np.log1p(
        df["Gross fixed capital formation, all, Constant prices, Percent of GDP"]
    )
    df["log_Production_Value"] = np.log1p(df["Total_Production_Value_Per_Capita"])

    # Mean-centred interactions (grand mean recomputed per bootstrap sample)
    for col in ["log_HCI", "log_GFCF", "log_Production_Value"]:
        df[f"{col}_c"] = df[col] - df[col].mean()

    df["log_HCI_x_log_Production"] = (
        df["log_HCI_c"] * df["log_Production_Value_c"]
    )
    df["log_GFCF_x_log_Production"] = (
        df["log_GFCF_c"] * df["log_Production_Value_c"]
    )

    # Lagged ECI
    df = df.sort_values(["Country Code", "Year"]).reset_index(drop=True)
    df["ECI_lag1"] = df.groupby("Country Code")["Economic Complexity Index"].shift(1)

    return df


def fit_model_3a(df: pd.DataFrame) -> dict:
    """Fit Model 3a (no lag) via OLS. Returns coefficient dict or None."""
    cols = reg3_input + INTERACT_VARS + ["Economic Complexity Index"]
    reg_df = df[cols].dropna()
    if len(reg_df) < 30:
        return None

    y = reg_df["Economic Complexity Index"]
    X = sm.add_constant(reg_df[reg3_input + INTERACT_VARS])
    fit = sm.OLS(y, X).fit()

    result = {"n_obs": int(fit.nobs), "r2": fit.rsquared}
    for var in fit.params.index:
        result[f"coef__{var}"] = fit.params[var]
        result[f"se__{var}"] = fit.bse[var]
    return result


def fit_model_3b(df: pd.DataFrame) -> dict:
    """Fit Model 3b (with lagged ECI) via OLS. Returns coefficient dict or None."""
    cols = reg3_input + INTERACT_VARS + ["ECI_lag1", "Economic Complexity Index"]
    reg_df = df[cols].dropna()
    if len(reg_df) < 30:
        return None

    y = reg_df["Economic Complexity Index"]
    X = sm.add_constant(reg_df[reg3_input + INTERACT_VARS + ["ECI_lag1"]])
    fit = sm.OLS(y, X).fit()

    result = {"n_obs": int(fit.nobs), "r2": fit.rsquared}
    for var in fit.params.index:
        result[f"coef__{var}"] = fit.params[var]
        result[f"se__{var}"] = fit.bse[var]
    return result


# ── Main loop ─────────────────────────────────────────────────────────────────

boot_files = sorted(glob.glob(os.path.join(BOOT_DIR, "Master_b*.csv")))
B = len(boot_files)

if B == 0:
    raise FileNotFoundError(
        f"No bootstrap files found in {BOOT_DIR}/. Run bootstrap_nb3.py first."
    )

print("=" * 70)
print(f"NB6 BOOTSTRAP EVALUATION: {B} iterations")
print("=" * 70)

results_3a = []
results_3b = []
skipped = 0

t0 = time.time()
for i, fpath in enumerate(boot_files, 1):
    df_b = prepare_regression_df(fpath)
    if df_b is None:
        skipped += 1
        continue

    r3a = fit_model_3a(df_b)
    r3b = fit_model_3b(df_b)

    if r3a is not None:
        r3a["b"] = i
        results_3a.append(r3a)
    if r3b is not None:
        r3b["b"] = i
        results_3b.append(r3b)

    if i % 50 == 0 or i == 1:
        elapsed = time.time() - t0
        print(f"  Iteration {i:>3d}/{B}  |  {elapsed:.1f}s elapsed")

elapsed = time.time() - t0
print(f"\nCompleted: {B - skipped} successful / {skipped} skipped in {elapsed:.1f}s")

df_3a = pd.DataFrame(results_3a)
df_3b = pd.DataFrame(results_3b)

df_3a.to_csv(os.path.join(BOOT_DIR, "nb6_boot_coefs_3a.csv"), index=False)
df_3b.to_csv(os.path.join(BOOT_DIR, "nb6_boot_coefs_3b.csv"), index=False)


# ── Summary: Bootstrap CIs and comparison with original estimates ─────────────

lo = ALPHA / 2
hi = 1 - ALPHA / 2

# Variables of interest (all regressors in Models 3a/3b)
vars_3a = ["const"] + reg3_input + INTERACT_VARS
vars_3b = vars_3a + ["ECI_lag1"]


def summarise_model(boot_df, var_list, original_model, model_label):
    """
    Print bootstrap summary for one model specification.

    For each coefficient, reports:
        - Original point estimate (from the main NB6 run)
        - Original Driscoll-Kraay SE
        - Bootstrap median
        - Bootstrap SE (SD of B point estimates)
        - Bootstrap 95% percentile CI
        - % of bootstrap samples where the coefficient has the same sign
          as the original (sign stability)
    """
    print(f"\n{'=' * 90}")
    print(f"{model_label}")
    print(f"{'=' * 90}")
    print(
        f"  {'Variable':<40} {'Orig':>8} {'DK-SE':>8} "
        f"{'Boot med':>9} {'Boot SE':>8} {'CI lo':>8} {'CI hi':>8} {'Sign%':>6}"
    )
    print("  " + "-" * 88)

    summary_rows = []
    for var in var_list:
        coef_col = f"coef__{var}"
        if coef_col not in boot_df.columns:
            continue

        vals = boot_df[coef_col].dropna()
        if len(vals) == 0:
            continue

        orig_coef = original_model.params.get(var, np.nan)
        orig_se = original_model.bse.get(var, np.nan)

        boot_med = vals.median()
        boot_se = vals.std()
        ci_lo = vals.quantile(lo)
        ci_hi = vals.quantile(hi)

        # Sign stability: fraction of bootstrap samples with same sign as original
        if orig_coef > 0:
            sign_pct = (vals > 0).mean()
        elif orig_coef < 0:
            sign_pct = (vals < 0).mean()
        else:
            sign_pct = np.nan

        sig_boot = "*" if (ci_lo > 0 or ci_hi < 0) else " "

        print(
            f"  {var:<40} {orig_coef:>+8.4f} {orig_se:>8.4f} "
            f"{boot_med:>+9.4f} {boot_se:>8.4f} "
            f"{ci_lo:>+8.4f} {ci_hi:>+8.4f} {sign_pct:>5.0%} {sig_boot}"
        )

        summary_rows.append({
            "Model": model_label,
            "Variable": var,
            "Original_Coef": orig_coef,
            "DK_SE": orig_se,
            "Boot_Median": boot_med,
            "Boot_SE": boot_se,
            "Boot_CI_lo": ci_lo,
            "Boot_CI_hi": ci_hi,
            "Sign_Stability": sign_pct,
            "Boot_Significant": sig_boot.strip() == "*",
        })

    # R-squared
    r2_vals = boot_df["r2"].dropna()
    print(
        f"\n  R²: original={original_model.rsquared:.4f}  "
        f"boot median={r2_vals.median():.4f}  "
        f"CI=[{r2_vals.quantile(lo):.4f}, {r2_vals.quantile(hi):.4f}]"
    )

    return summary_rows


all_summary = []

# Model 3a
# m3a is the original Model 3a result from NB6 (SimpleNamespace with .params, .bse)
all_summary.extend(
    summarise_model(df_3a, vars_3a, m3a, "MODEL 3a (no lag)")
)

# Model 3b
all_summary.extend(
    summarise_model(df_3b, vars_3b, m3b, "MODEL 3b (with lag)")
)

# Save combined summary
summary_df = pd.DataFrame(all_summary)
summary_df.to_csv(os.path.join(BOOT_DIR, "nb6_boot_summary.csv"), index=False)


# ── Interpretation guide ──────────────────────────────────────────────────────

print("\n" + "=" * 90)
print("INTERPRETATION GUIDE")
print("=" * 90)
print("""
  Boot SE vs DK-SE:
    If Boot SE > DK-SE, the Driscoll-Kraay SEs understate uncertainty
    because they do not account for imputation variability. The bootstrap
    SE is the more conservative (and more honest) estimate.

  Sign Stability:
    Values above 95% mean the coefficient's sign is robust to both
    resampling and re-imputation. Values below 80% indicate fragility:
    the sign depends on which countries happen to be in the sample or
    on how missing values are filled.

  Bootstrap CI:
    If the 95% percentile CI excludes zero (marked with *), the
    coefficient is significant under the bootstrap. Compare with the
    original Driscoll-Kraay inference: if a coefficient is significant
    under DK but not under the bootstrap, imputation uncertainty is
    the likely explanation.
""")

print("Files saved:")
print(f"  {BOOT_DIR}/nb6_boot_coefs_3a.csv")
print(f"  {BOOT_DIR}/nb6_boot_coefs_3b.csv")
print(f"  {BOOT_DIR}/nb6_boot_summary.csv")
print("=" * 90)
