"""
bootstrap_nb5.py
────────────────────────────────────────────────────────────────────────────────
Bootstrap evaluation for the ML pipeline (NB5).

This script loops over the B bootstrapped Master files produced by
bootstrap_nb3.py. For each iteration it re-does feature engineering,
train/test splitting, model fitting, and stores test-set metrics and
feature importances. After the loop it computes bootstrap confidence
intervals and summary statistics.

USAGE
-----
Paste into a new cell at the end of NB5, after the original pipeline
has run (so that functions like fit_all_models, PanelTemporalCV, and
constants like all_features, base_features, new_features, etc. exist).

Alternatively, run as a standalone script after executing NB5 once.

OUTPUT
------
    intermediary/bootstrap/nb5_boot_metrics.csv
    intermediary/bootstrap/nb5_boot_importances.csv
    intermediary/bootstrap/nb5_boot_coefs.csv
    intermediary/bootstrap/nb5_boot_lasso_selection.csv
    Console: bootstrap confidence intervals for key quantities
"""

import os
import time
import glob
import warnings
import numpy as np
import pandas as pd
from sklearn.linear_model import LassoCV, RidgeCV, ElasticNetCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

warnings.filterwarnings("ignore")

# ── Configuration ─────────────────────────────────────────────────────────────
BOOT_DIR = "intermediary/bootstrap"
TRAIN_END = 2014
TEST_START = 2015
ALPHA = 0.05  # for 95% bootstrap CIs

# 54-country sample (same as NB5)
INCLUDE = [
    'AGO', 'ARE', 'AZE', 'BFA', 'BHR', 'BOL', 'CHL', 'CIV', 'CMR',
    'COD', 'COG', 'DZA', 'ECU', 'EGY', 'ETH', 'GAB', 'GHA', 'GIN',
    'GNQ', 'IDN', 'IRN', 'IRQ', 'KAZ', 'KEN', 'KWT', 'LAO', 'LBR',
    'LBY', 'MDG', 'MLI', 'MMR', 'MNG', 'MOZ', 'MWI', 'MYS', 'NER',
    'NGA', 'OMN', 'PNG', 'QAT', 'RUS', 'RWA', 'SAU', 'TCD', 'TGO',
    'TTO', 'TZA', 'UGA', 'UZB', 'VEN', 'VNM', 'YEM', 'ZMB', 'ZWE',
]

# Feature lists (must match NB5 exactly)
base_features = [
    'Total_Production_Value_Per_Capita',
    'Human capital index',
    'Rule of law index',
    'Political stability — estimate',
    'Trade (% of GDP)',
    'Gross fixed capital formation, all, Constant prices, Percent of GDP',
    'Share of investment in GDP',
    'Domestic credit to private sector (% of GDP)',
    'Landlocked',
    'Urban population (% of total population)',
    'Government revenue',
    'Capital depreciation rate',
    'Use of IMF credit (DOD, current US$)',
    'Real interest rate (%)',
    'Inflation, consumer prices (annual %)',
    'Access to electricity (% of population)',
    'Adjusted savings: gross savings (% of GNI)',
    'L1_ECI',
]
new_features = ['Inflation_roll5', 'RealRate_roll5', 'Resource_HHI']
interaction_features = ['HCI_x_ProductionValue', 'RuleOfLaw_x_ProductionValue']
all_features = base_features + new_features + interaction_features


def prepare_bootstrap_df(filepath: str) -> pd.DataFrame:
    """
    Load a bootstrapped Master file and apply the same feature engineering
    as NB5 Cell 4. Returns the ready-to-model DataFrame or None if the
    bootstrap sample is too small after dropna.
    """
    master = pd.read_csv(filepath)
    df = master[master["Country Code"].isin(INCLUDE)].copy()

    if len(df) == 0:
        return None

    # Per-capita production value
    df["Total_Production_Value_Per_Capita"] = (
        df["Total_Production_Value"] / df["Population"]
    )

    df = df.sort_values(["Country Code", "Year"]).reset_index(drop=True)

    # Rolling macro controls
    df["Inflation_roll5"] = df.groupby("Country Code")[
        "Inflation, consumer prices (annual %)"
    ].transform(lambda x: x.rolling(5, min_periods=3).mean())

    df["RealRate_roll5"] = df.groupby("Country Code")[
        "Real interest rate (%)"
    ].transform(lambda x: x.rolling(5, min_periods=3).mean())

    # Resource concentration HHI
    rents_cols = [
        "Oil rents (% of GDP)",
        "Natural gas rents (% of GDP)",
        "Mineral rents (% of GDP)",
    ]
    total_rents = df["Total natural resources rents (% of GDP)"].replace(0, np.nan)
    df["Resource_HHI"] = sum((df[col] / total_rents) ** 2 for col in rents_cols)

    # ECI targets
    df["L1_ECI"] = df.groupby("Country Code")["Economic Complexity Index"].shift(1)
    df["ECI_delta"] = df["Economic Complexity Index"] - df["L1_ECI"]
    df = df.dropna(subset=["L1_ECI", "Economic Complexity Index", "ECI_delta"])

    # Log transforms (before interactions)
    log_cols = [
        "Human capital index",
        "Total_Production_Value_Per_Capita",
        "Gross fixed capital formation, all, Constant prices, Percent of GDP",
        "Government revenue",
        "Use of IMF credit (DOD, current US$)",
    ]
    df[log_cols] = np.log1p(df[log_cols]).replace([np.inf, -np.inf], np.nan)

    # Mean-centred interactions (grand mean recomputed per bootstrap sample)
    hci_mean = df["Human capital index"].mean()
    prod_mean = df["Total_Production_Value_Per_Capita"].mean()
    rol_mean = df["Rule of law index"].mean()

    df["HCI_x_ProductionValue"] = (df["Human capital index"] - hci_mean) * (
        df["Total_Production_Value_Per_Capita"] - prod_mean
    )
    df["RuleOfLaw_x_ProductionValue"] = (df["Rule of law index"] - rol_mean) * (
        df["Total_Production_Value_Per_Capita"] - prod_mean
    )

    df = df.dropna(subset=all_features)

    if len(df) < 50:
        return None

    return df


def fit_and_evaluate(df: pd.DataFrame) -> dict:
    """
    Replicate the NB5 train/test pipeline on a single bootstrap sample.
    Returns a dict with metrics, coefficients, and importances.
    """
    train_df = df[df["Year"] <= TRAIN_END].copy()
    test_df = df[df["Year"] >= TEST_START].copy()

    if len(train_df) < 30 or len(test_df) < 10:
        return None

    y_train = train_df["Economic Complexity Index"].values
    y_test = test_df["Economic Complexity Index"].values
    y_train_delta = train_df["ECI_delta"].values
    y_test_delta = test_df["ECI_delta"].values

    scaler = StandardScaler()
    X_train = scaler.fit_transform(train_df[all_features].values)
    X_test = scaler.transform(test_df[all_features].values)

    train_years = train_df["Year"].values
    tscv = PanelTemporalCV(train_years, n_splits=5, gap=1, min_train_years=8)

    # Fit models (skip XGBoost inside bootstrap for speed)
    lasso = LassoCV(cv=tscv, random_state=42, max_iter=10000).fit(X_train, y_train)
    ridge = RidgeCV(alphas=np.logspace(-3, 3, 100), cv=tscv).fit(X_train, y_train)
    elastic = ElasticNetCV(
        l1_ratio=[0.5], cv=tscv, random_state=42, max_iter=10000
    ).fit(X_train, y_train)
    rf = RandomForestRegressor(
        n_estimators=200, max_depth=4, min_samples_leaf=10, random_state=42, n_jobs=-1
    ).fit(X_train, y_train)

    models = {"LASSO": lasso, "Ridge": ridge, "Elastic Net": elastic, "Random Forest": rf}

    # Evaluate on test set
    metrics = {}
    for name, model in models.items():
        pred_te = model.predict(X_test)
        metrics[f"{name}_test_r2"] = r2_score(y_test, pred_te)
        metrics[f"{name}_test_rmse"] = np.sqrt(mean_squared_error(y_test, pred_te))
        metrics[f"{name}_test_mae"] = mean_absolute_error(y_test, pred_te)

    # Also evaluate delta target for RF
    rf_delta = RandomForestRegressor(
        n_estimators=200, max_depth=4, min_samples_leaf=10, random_state=42, n_jobs=-1
    ).fit(X_train, y_train_delta)
    pred_delta = rf_delta.predict(X_test)
    metrics["RF_delta_test_r2"] = r2_score(y_test_delta, pred_delta)

    metrics["n_train"] = len(train_df)
    metrics["n_test"] = len(test_df)
    metrics["n_countries"] = df["Country Code"].nunique()

    # Coefficients from linear models
    coefs = {}
    for name, model in models.items():
        if hasattr(model, "coef_"):
            for feat, c in zip(all_features, model.coef_):
                coefs[f"{name}__{feat}"] = c

    # Feature importances from RF
    importances = dict(zip(all_features, rf.feature_importances_))

    # LASSO selection indicator
    lasso_selected = {
        feat: int(c != 0) for feat, c in zip(all_features, lasso.coef_)
    }

    return {
        "metrics": metrics,
        "coefs": coefs,
        "importances": importances,
        "lasso_selected": lasso_selected,
    }


# ── Main loop ─────────────────────────────────────────────────────────────────

boot_files = sorted(glob.glob(os.path.join(BOOT_DIR, "Master_b*.csv")))
B = len(boot_files)

if B == 0:
    raise FileNotFoundError(
        f"No bootstrap files found in {BOOT_DIR}/. Run bootstrap_nb3.py first."
    )

print("=" * 70)
print(f"NB5 BOOTSTRAP EVALUATION: {B} iterations")
print("=" * 70)

all_metrics = []
all_coefs = []
all_importances = []
all_lasso_sel = []
skipped = 0

t0 = time.time()
for i, fpath in enumerate(boot_files, 1):
    df_b = prepare_bootstrap_df(fpath)
    if df_b is None:
        skipped += 1
        continue

    result = fit_and_evaluate(df_b)
    if result is None:
        skipped += 1
        continue

    result["metrics"]["b"] = i
    all_metrics.append(result["metrics"])

    result["coefs"]["b"] = i
    all_coefs.append(result["coefs"])

    result["importances"]["b"] = i
    all_importances.append(result["importances"])

    result["lasso_selected"]["b"] = i
    all_lasso_sel.append(result["lasso_selected"])

    if i % 25 == 0 or i == 1:
        elapsed = time.time() - t0
        rate = i / elapsed
        eta = (B - i) / rate
        print(f"  Iteration {i:>3d}/{B}  |  {elapsed:.0f}s elapsed  |  ETA {eta:.0f}s")

elapsed = time.time() - t0
print(f"\nCompleted: {B - skipped} successful / {skipped} skipped in {elapsed:.1f}s")

# ── Assemble results ──────────────────────────────────────────────────────────

metrics_df = pd.DataFrame(all_metrics)
coefs_df = pd.DataFrame(all_coefs)
imp_df = pd.DataFrame(all_importances)
sel_df = pd.DataFrame(all_lasso_sel)

metrics_df.to_csv(os.path.join(BOOT_DIR, "nb5_boot_metrics.csv"), index=False)
coefs_df.to_csv(os.path.join(BOOT_DIR, "nb5_boot_coefs.csv"), index=False)
imp_df.to_csv(os.path.join(BOOT_DIR, "nb5_boot_importances.csv"), index=False)
sel_df.to_csv(os.path.join(BOOT_DIR, "nb5_boot_lasso_selection.csv"), index=False)

# ── Summary: Bootstrap confidence intervals ───────────────────────────────────

lo = ALPHA / 2
hi = 1 - ALPHA / 2

print("\n" + "=" * 70)
print("BOOTSTRAP CONFIDENCE INTERVALS (95%)")
print("=" * 70)

# Test R-squared
print("\n── Test R² ──")
for model_name in ["LASSO", "Ridge", "Elastic Net", "Random Forest"]:
    col = f"{model_name}_test_r2"
    vals = metrics_df[col].dropna()
    print(
        f"  {model_name:<16}  "
        f"median={vals.median():.4f}  "
        f"mean={vals.mean():.4f}  "
        f"CI=[{vals.quantile(lo):.4f}, {vals.quantile(hi):.4f}]  "
        f"SD={vals.std():.4f}"
    )

# Test RMSE
print("\n── Test RMSE ──")
for model_name in ["LASSO", "Ridge", "Elastic Net", "Random Forest"]:
    col = f"{model_name}_test_rmse"
    vals = metrics_df[col].dropna()
    print(
        f"  {model_name:<16}  "
        f"median={vals.median():.4f}  "
        f"CI=[{vals.quantile(lo):.4f}, {vals.quantile(hi):.4f}]"
    )

# RF feature importance stability
print("\n── RF Feature Importance (top 10 by median) ──")
feat_cols = [c for c in imp_df.columns if c != "b"]
medians = imp_df[feat_cols].median().sort_values(ascending=False)
for feat in medians.head(10).index:
    vals = imp_df[feat].dropna()
    print(
        f"  {feat[:40]:<42}  "
        f"median={vals.median():.4f}  "
        f"CI=[{vals.quantile(lo):.4f}, {vals.quantile(hi):.4f}]"
    )

# LASSO selection frequency
print("\n── LASSO Selection Frequency (% of bootstrap samples) ──")
feat_cols_sel = [c for c in sel_df.columns if c != "b"]
sel_freq = sel_df[feat_cols_sel].mean().sort_values(ascending=False)
for feat, freq in sel_freq.items():
    marker = " *** STABLE" if freq > 0.90 else " *  unstable" if freq < 0.50 else ""
    print(f"  {feat[:40]:<42}  {freq:.1%}{marker}")

# Elastic Net coefficient stability
print("\n── Elastic Net Coefficient Signs (% positive across bootstrap) ──")
en_cols = [c for c in coefs_df.columns if c.startswith("Elastic Net__")]
for col in en_cols:
    feat = col.replace("Elastic Net__", "")
    vals = coefs_df[col].dropna()
    if len(vals) == 0:
        continue
    pct_pos = (vals > 0).mean()
    pct_neg = (vals < 0).mean()
    pct_zero = (vals == 0).mean()
    sign = "+" if pct_pos > 0.7 else ("-" if pct_neg > 0.7 else "?")
    print(
        f"  {feat[:40]:<42}  "
        f"sign={sign}  +:{pct_pos:.0%}  -:{pct_neg:.0%}  0:{pct_zero:.0%}  "
        f"median={vals.median():+.4f}"
    )

print("\n" + "=" * 70)
print("Files saved:")
print(f"  {BOOT_DIR}/nb5_boot_metrics.csv")
print(f"  {BOOT_DIR}/nb5_boot_coefs.csv")
print(f"  {BOOT_DIR}/nb5_boot_importances.csv")
print(f"  {BOOT_DIR}/nb5_boot_lasso_selection.csv")
print("=" * 70)
