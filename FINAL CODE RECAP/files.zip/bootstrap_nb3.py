"""
bootstrap_nb3.py
────────────────────────────────────────────────────────────────────────────────
Bootstrap wrapper for the NB3 imputation pipeline.

This script runs AFTER the main NB3 notebook has executed (so that all
intermediate objects exist). It resamples countries with replacement,
re-runs the two-stage imputation (linear interpolation then KNN), and
saves B separate Master files for downstream bootstrap evaluation in
NB5 and NB6.

USAGE
-----
Paste this into a new cell at the end of NB3, after all the original
cells have run. The variables it depends on are:

    df_imputed          : DataFrame after sample selection + variable filtering
                          (output of the "Merge with Master Data" cell, before
                          imputation). This is the pre-imputation panel with
                          NaN gaps still present.
    nrpv                : NR clean data (for saving alongside each bootstrap)
    df_long             : Population data (for the final merge)
    impute_linear_interpolation : function defined in NB3 Cell 25
    apply_knn_imputer           : function defined in NB3 Cell 28
    EXCLUDE_VARS, EXCLUDE_VARS_KNN, MAX_GAP : constants from NB3

If any of these are missing, re-run the NB3 cells that produce them.

OUTPUT
------
    intermediary/bootstrap/Master_b001.csv  ...  Master_b{B}.csv
    intermediary/bootstrap/bootstrap_log.csv   (country draws per iteration)
"""

import os
import time
import numpy as np
import pandas as pd

# ── Configuration ─────────────────────────────────────────────────────────────
B = 200                 # number of bootstrap iterations
KNN_NEIGHBORS = 5       # same as the main pipeline
RANDOM_SEED = 12345     # master seed for reproducibility

BOOT_DIR = "intermediary/bootstrap"
os.makedirs(BOOT_DIR, exist_ok=True)


def bootstrap_imputation_loop(
    df_pre_impute: pd.DataFrame,
    pop_df: pd.DataFrame,
    B: int = 200,
    knn_neighbors: int = 5,
    seed: int = 12345,
    verbose: bool = True,
):
    """
    Country-level block bootstrap of the imputation pipeline.

    For each iteration b = 1..B:
        1. Draw N countries with replacement (where N = number of unique
           countries in the sample). Each drawn country keeps its full
           1995-2019 time series intact.
        2. Re-run linear interpolation (capped at MAX_GAP=3 years).
        3. Re-run KNN imputation on the resampled panel.
        4. Merge population data.
        5. Save as Master_b{NNN}.csv.

    When a country is drawn more than once, each copy enters the panel
    as a separate synthetic unit with a suffixed country code (e.g.
    AGO, AGO_2, AGO_3). This preserves the panel structure within each
    unit while allowing the bootstrap to vary the country composition.

    Parameters
    ----------
    df_pre_impute : DataFrame
        The panel AFTER sample selection and variable filtering but
        BEFORE imputation. Must contain 'Country Code', 'Country Name',
        'Year', and all analysis variables with NaN gaps.
    pop_df : DataFrame
        Population data with columns ['Country Code', 'Year', 'Population'].
    B : int
        Number of bootstrap replications.
    knn_neighbors : int
        k for the KNN imputer.
    seed : int
        Master RNG seed.
    verbose : bool
        Print progress updates.
    """

    rng = np.random.RandomState(seed)
    countries = df_pre_impute["Country Code"].unique()
    N = len(countries)

    log_rows = []
    t0 = time.time()

    for b in range(1, B + 1):
        # ── 1. Draw countries with replacement ────────────────────────────
        drawn = rng.choice(countries, size=N, replace=True)

        # Build the bootstrap panel. If a country appears k times, create
        # k copies with suffixed codes so that each copy is treated as an
        # independent unit by the imputer.
        frames = []
        counts = {}
        for cc in drawn:
            counts[cc] = counts.get(cc, 0) + 1
            chunk = df_pre_impute[
                df_pre_impute["Country Code"] == cc
            ].copy()
            if counts[cc] > 1:
                suffix = f"_{counts[cc]}"
                chunk["Country Code"] = cc + suffix
                chunk["Country Name"] = chunk["Country Name"] + suffix
            # Store original code for the population merge later
            chunk["_original_cc"] = cc
            frames.append(chunk)

        boot_panel = pd.concat(frames, ignore_index=True)

        # ── 2. Linear interpolation ───────────────────────────────────────
        boot_interp = impute_linear_interpolation(boot_panel, max_gap=MAX_GAP)

        # ── 3. KNN imputation ─────────────────────────────────────────────
        boot_imp, _ = apply_knn_imputer(boot_interp, n_neighbors=knn_neighbors)

        # ── 4. Merge population (use original country code) ───────────────
        boot_imp = boot_imp.merge(
            pop_df[["Country Code", "Year", "Population"]].rename(
                columns={"Country Code": "_original_cc"}
            ),
            on=["_original_cc", "Year"],
            how="left",
        )
        # Restore original country code (strip bootstrap suffixes) so that
        # downstream notebooks can group by the real 54-country list.
        boot_imp["Country Code"] = boot_imp["_original_cc"]
        boot_imp.drop(columns=["_original_cc"], inplace=True)

        # ── 5. Save ──────────────────────────────────────────────────────
        out_path = os.path.join(BOOT_DIR, f"Master_b{b:03d}.csv")
        boot_imp.to_csv(out_path, index=False)

        # Log which countries were drawn
        log_rows.append({
            "b": b,
            "countries_drawn": ",".join(drawn),
            "unique_drawn": len(set(drawn)),
            "n_rows": len(boot_imp),
        })

        if verbose and (b % 25 == 0 or b == 1):
            elapsed = time.time() - t0
            rate = b / elapsed
            eta = (B - b) / rate
            print(
                f"  Bootstrap {b:>3d}/{B}  |  "
                f"{len(boot_imp):,} rows  |  "
                f"{len(set(drawn))}/{N} unique countries  |  "
                f"ETA {eta:.0f}s"
            )

    # Save the bootstrap log
    log_df = pd.DataFrame(log_rows)
    log_df.to_csv(os.path.join(BOOT_DIR, "bootstrap_log.csv"), index=False)

    elapsed = time.time() - t0
    print(f"\nBootstrap complete: {B} iterations in {elapsed:.1f}s")
    print(f"Saved to {BOOT_DIR}/Master_b001.csv .. Master_b{B:03d}.csv")
    print(f"Log: {BOOT_DIR}/bootstrap_log.csv")


# ── Run ───────────────────────────────────────────────────────────────────────
# Suppress the per-iteration imputation print statements by temporarily
# redirecting stdout to /dev/null. Remove the context manager if you
# want full verbosity.

import io, contextlib

print("=" * 70)
print(f"BOOTSTRAP IMPUTATION: {B} iterations, {KNN_NEIGHBORS}-NN, seed={RANDOM_SEED}")
print("=" * 70)

# df_imputed is the pre-KNN panel from NB3 (after linear interpolation cell).
# If you want to bootstrap from before interpolation, use the panel just
# after the "Merge with Master Data and Apply Filters" cell instead.
# The variable name depends on your NB3 naming; adjust if needed.
#
# df_long is the population DataFrame from NB3 Cell 34.

# Wrap each iteration's imputation functions in a silence context
# so the console isn't flooded with 200 x 2 imputation reports.
_real_impute_linear = impute_linear_interpolation
_real_knn = apply_knn_imputer

def _quiet_interpolation(df, max_gap=MAX_GAP):
    with contextlib.redirect_stdout(io.StringIO()):
        return _real_impute_linear(df, max_gap=max_gap)

def _quiet_knn(df, n_neighbors=5):
    with contextlib.redirect_stdout(io.StringIO()):
        return _real_knn(df, n_neighbors=n_neighbors)

# Temporarily replace the functions
impute_linear_interpolation = _quiet_interpolation
apply_knn_imputer = _quiet_knn

try:
    bootstrap_imputation_loop(
        df_pre_impute=df_imputed,  # <-- adjust variable name if needed
        pop_df=df_long,
        B=B,
        knn_neighbors=KNN_NEIGHBORS,
        seed=RANDOM_SEED,
        verbose=True,
    )
finally:
    # Restore original functions
    impute_linear_interpolation = _real_impute_linear
    apply_knn_imputer = _real_knn
